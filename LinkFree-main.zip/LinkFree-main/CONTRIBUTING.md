# Contributing Guide

Please see the `docs` in the app https://linkfree.eddiehub.io/docs
