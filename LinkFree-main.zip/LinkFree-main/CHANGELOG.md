## [1.40.8](https://github.com/EddieHubCommunity/LinkFree/compare/v1.40.7...v1.40.8) (2023-01-05)


### Bug Fixes

* docs line break ([#2688](https://github.com/EddieHubCommunity/LinkFree/issues/2688)) ([529c5dc](https://github.com/EddieHubCommunity/LinkFree/commit/529c5dcba084b9d8bdce795d30d767934e9623ad))



## [1.40.7](https://github.com/EddieHubCommunity/LinkFree/compare/v1.40.6...v1.40.7) (2023-01-05)


### Bug Fixes

* testimonial action with jq ([d7481ca](https://github.com/EddieHubCommunity/LinkFree/commit/d7481ca952a5d494c46632eb1aa74c2b5cbb6eb7))



## [1.40.6](https://github.com/EddieHubCommunity/LinkFree/compare/v1.40.5...v1.40.6) (2023-01-04)


### Bug Fixes

* testimonial gh action trigger ([5de6d7b](https://github.com/EddieHubCommunity/LinkFree/commit/5de6d7b19f98214cd13c491bd4e595925765c50b))



## [1.40.5](https://github.com/EddieHubCommunity/LinkFree/compare/v1.40.4...v1.40.5) (2023-01-04)


### Bug Fixes

* github action jq to apt ([0022406](https://github.com/EddieHubCommunity/LinkFree/commit/00224060dd733ad66182efa8c4dc1709a45a2e36))



## [1.40.4](https://github.com/EddieHubCommunity/LinkFree/compare/v1.40.3...v1.40.4) (2023-01-04)


### Bug Fixes

* github action for jq ([7bdc59c](https://github.com/EddieHubCommunity/LinkFree/commit/7bdc59c8aaaa4ce8915b0399102eee0b65cb35c7))



